dbxtool
=======

tool for managing dbx updates installed on a machine.
